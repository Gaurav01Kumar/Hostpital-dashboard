import React from 'react'

const Logo = () => {
  return (
    <h1 className='cursor-pointer text-2xl' style={{fontFamily:"cursive"}}>Oxyy</h1>
  )
}

export default Logo